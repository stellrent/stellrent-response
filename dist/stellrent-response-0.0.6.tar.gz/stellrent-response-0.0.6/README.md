# STELLRENT - Response pattern

Pattern responses for REST API Projects