# STELLRENT - Response pattern

Pattern responses for REST API Projects using Flask

## Development

### Requirements

* Visual Studio Code v1.95.2
* Python v3.11.*

### Testing
Use VS Code snippet "Testing"

### GITHUB Authentication
Using SSH Authentication keys